var s = {
  'a':'b'
};

if(s['a'])
  console.log("있습니다");

if(!s['b'])
  console.log('b는 없습니다');
