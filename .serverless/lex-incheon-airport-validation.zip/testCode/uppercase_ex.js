var string = "hello world";
string = string.charAt(0).toUpperCase() + string.slice(1);
console.log(string);
