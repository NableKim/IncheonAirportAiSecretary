'use strict';

/*
 * departureTimeManageFulfillment.js - to make flight information that user wants to know
 *
 * Incheon Airport AI Secretary based on AWS Lex
 *
 * Created by Nablekim94@gmail.com 2018-07-15
*/

const lexResponses = require('../lexResponses');
const getDataFromAPI = require('../getDataFromAPI');
const _ = require('lodash');

module.exports = function(intentRequest, callback) {
  console.log("departureTimeManageFulfillment was called...");
  //var faFindingArea=intentRequest.currentIntent.slots.faFindingArea;


};
