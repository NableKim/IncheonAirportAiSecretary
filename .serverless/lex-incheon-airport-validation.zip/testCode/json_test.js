var j = {
  'a' : {
    'bb' : 'bbb'
  },
  'b' : 'bb'
};
j.a.aa='aaa';
console.log(j.a['aa']);
